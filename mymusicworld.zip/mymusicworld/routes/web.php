<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\myController;



Route::get('/',[myController::class,'index']);
Route::get('/music',[myController::class,'music']);

?>