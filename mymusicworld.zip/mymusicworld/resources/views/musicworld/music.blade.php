@extends('musicworld.master')
@section('content')

<!-- music -->
<div class="about w3_music">
		<div class="container">
			<h3 class="agileits_w3layouts_head">Symphony <span>music</span> Schedule</h3>
			<p class="w3_agileits_para">Quisque faucibus vel leo a luctus.</p>
			<div class="wthree_latest_albums_grids">
				<div class="cntl"> <span class="cntl-bar cntl-center"> <span class="cntl-bar-fill"></span> </span>
					<div class="cntl-states">
						<div class="cntl-state">
							<div class="cntl-content">
								<h4>15 December 2016</h4>
								<p>Singing Classes</p>
							</div>
							<div class="cntl-image">
								<img src="images/7.jpg" alt=" " class="img-responsive" />
								<div class="w3ls_cntl_image_pos">
									<p>Duis a diam nec dui rutrum dapibus eget vitae nulla</p>
								</div>
							</div>
							<div class="cntl-icon cntl-center">01</div>
						</div>
						<div class="cntl-state">
							<div class="cntl-content">
								<h4>18 December 2016</h4>
								<p>Nulla ut tellus eu ante dapibus euismod ut sit amet est. Sed posuere scelerisque turpis, in bibendum magna feugiat non.</p>
							</div>
							<div class="cntl-image w3_cntl_image"><img src="images/10.jpg" alt=" " class="img-responsive" /></div>
							<div class="cntl-icon cntl-center">02</div>
						</div>
						<div class="cntl-state">
							<div class="cntl-content">
								<h4>21 December 2016</h4>
								<p>Hormonica Classes</p>
							</div>
							<div class="cntl-image">
								<img src="images/3.jpg" alt=" " class="img-responsive" />
								<div class="w3ls_cntl_image_pos">
									<p>Duis a diam nec dui rutrum dapibus eget vitae nulla</p>
								</div>
							</div>
							<div class="cntl-icon cntl-center">03</div>
						</div>
						<div class="cntl-state">
							<div class="cntl-content">
								<h4>25 December 2016</h4>
								<p>Nulla ut tellus eu ante dapibus euismod ut sit amet est. Sed posuere scelerisque turpis, in bibendum magna feugiat non.</p>
							</div>
							<div class="cntl-image">
								<img src="images/2.jpg" alt=" " class="img-responsive" />
								<div class="w3ls_cntl_image_pos">
									<p>Duis a diam nec dui rutrum dapibus eget vitae nulla</p>
								</div>
							</div>
							<div class="cntl-icon cntl-center">04</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<!-- //music -->

@stop
