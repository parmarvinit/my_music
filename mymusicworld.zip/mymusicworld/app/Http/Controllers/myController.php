<?php 
namespace App\Http\controllers;

use Illuminate\Http\Request;

class myController extends controller 
{
    function index(){
        return view('musicworld.home');
    }
    function music(){
        return view('musicworld.music');
    }



}
?>